export const DATE_FORMAT = 'YYYY-MM-DD';

export const COMPLETED = 'completed';

export const FAILED = 'failed';

export const EMPTY = 'empty';

export const CHECKMARK_VALUES = [EMPTY, COMPLETED, FAILED];
